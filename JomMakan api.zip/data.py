food = [
    "Nasi Ayam", "Nasi Kerabu", "Mee Goreng",
    "Mee Kuah",
    "Mee Bandung", "Laksa",
    "Maggi Kerabu", "Ayam Masak Merah", "Chicken Chop",
    "Bubur Ayam", "Bubur Pedas", "Nasi Kari",
    "Fish Fillet", "Tower Burger"
]

drinks = [
    "Coca-Cola", "Fanta Strawberry", "Fanta Grape", "Minute Maid Fresh Orange",
    "Heaven and Earth Iced Lemon", "Nescafe Tarik", "Tea Tarik", "Milo",
    "Nescafe Ice", "Tea Ice", "Milo Ice"
]

statuses = [
    "WAIT FOR ORDER", "ORDERED", "IN PROGRESS", "READY TO SERVE", "SERVED",
    "HOUSEKEEPING", "AVAILABLE"
]

tableinfo = {
    "A": {
        "drinks": {
            "itemdrink": [],
            "qdrink": []
        },
        "food": {
            "itemfood": [],
            "qfood": []
        },
        "status": statuses[6],
        "table": "A",
        "time": ""
    },
    "B": {
        "drinks": {
            "itemdrink": [],
            "qdrink": []
        },
        "food": {
            "itemfood": [],
            "qfood": []
        },
        "status": statuses[6],
        "table": "B",
        "time": ""
    },
    "C": {
        "drinks": {
            "itemdrink": [],
            "qdrink": []
        },
        "food": {
            "itemfood": [],
            "qfood": []
        },
        "status": statuses[6],
        "table": "C",
        "time": ""
    },
    "D": {
        "drinks": {
            "itemdrink": [],
            "qdrink": []
        },
        "food": {
            "itemfood": [],
            "qfood": []
        },
        "status": statuses[6],
        "table": "D",
        "time": ""
    },
    "E": {
        "drinks": {
            "itemdrink": [],
            "qdrink": []
        },
        "food": {
            "itemfood": [],
            "qfood": []
        },
        "status": statuses[6],
        "table": "E",
        "time": ""
    },
    "F": {
        "drinks": {
            "itemdrink": [],
            "qdrink": []
        },
        "food": {
            "itemfood": [],
            "qfood": []
        },
        "status": statuses[6],
        "table": "F",
        "time": ""
    },
}
